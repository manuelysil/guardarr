const imagem1 = document.getElementById("imagem1");
const imagem2 = document.getElementById("imagem2");
const imagem3 = document.getElementById("imagem3");
const verificarBtn = document.getElementById("verificar");
const mensagem = document.getElementById("mensagem");

let errosEncontrados = 0;
let fase2Desbloqueada = false;
let fase3Desbloqueada = false;

verificarBtn.addEventListener("click", () => {
    if (errosEncontrados < 5) {
        mensagem.textContent = "Você encontrou " + errosEncontrados + " de 5 erros. Continue procurando!";
    } else {
        mensagem.textContent = "Parabéns! Você encontrou todos os erros!";
        fase2Desbloqueada = true;
    }
});

imagem1.addEventListener("click" , () => {
    if (errosEncontrados < 5) {
        errosEncontrados++;
        imagem1.style.opacity = "0.5"; 
        mensagem.textContent = "Você encontrou " + errosEncontrados + " de 5 erros. Continue procurando!";
        fase2Desbloqueada = true;
    }
});

verificarBtn.addEventListener("click", () => {
    if (fase2Desbloqueada) {
        window.location.href = "fase2.html";
    }
});

verificarBtn.addEventListener("click", () => {
    if (errosEncontrados < 5) {
        mensagem.textContent = "Você encontrou " + errosEncontrados + " de 5 erros. Continue procurando!";
    } else {
        mensagem.textContent = "Parabéns! Você encontrou todos os erros!";
        fase3Desbloqueada = true;
    }
});

imagem2.addEventListener("click", () => {
    if (errosEncontrados < 5) {
        errosEncontrados++;
        imagem2.style.opacity = "0.5"; 
        mensagem.textContent = "Você encontrou " + errosEncontrados + " de 5 erros. Continue procurando!";
        fase3Desbloqueada = true;
    }
});

verificarBtn.addEventListener("click", () => {
    if (fase3Desbloqueada) {
        window.location.href = "fase3.html";
    }
});

verificarBtn.addEventListener("click", () => {
    if (errosEncontrados < 5) {
        mensagem.textContent = "Você encontrou " + errosEncontrados + " de 5 erros. Continue procurando!";
    } else {
        mensagem.textContent = "Parabéns! Você ganhou o jogo!";
    }
});

imagem3.addEventListener("click", () => {
    if (errosEncontrados < 5) {
        errosEncontrados++;
        imagem3.style.opacity = "0.5"; 
        mensagem.textContent = "Você encontrou " + errosEncontrados + " de 5 erros. Continue procurando!";
    }
});